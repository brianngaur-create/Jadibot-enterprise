import type { AuthUser, AuthSession, AuthTokens, LoginCredentials, RegisterCredentials } from './types'

const MOCK_ACCESS_TOKEN_EXPIRY_MS = 15 * 60 * 1000
const MOCK_REFRESH_TOKEN_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000
const MOCK_REFRESH_TOKEN_REMEMBER_EXPIRY_MS = 30 * 24 * 60 * 60 * 1000

export const MOCK_USERS: AuthUser[] = [
  {
    id: 'usr_1',
    email: 'user@jadibot.com',
    name: 'Arya Pratama',
    role: 'user',
    status: 'active',
    plan: 'pro',
    avatarInitials: 'AP',
    emailVerified: true,
    twoFactorEnabled: false,
    createdAt: '2024-01-10T00:00:00Z',
    lastLoginAt: new Date().toISOString(),
  },
  {
    id: 'usr_2',
    email: 'admin@jadibot.com',
    name: 'Admin User',
    role: 'admin',
    status: 'active',
    plan: 'enterprise',
    avatarInitials: 'AU',
    emailVerified: true,
    twoFactorEnabled: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLoginAt: new Date().toISOString(),
  },
  {
    id: 'usr_3',
    email: 'superadmin@jadibot.com',
    name: 'Super Admin',
    role: 'super_admin',
    status: 'active',
    plan: 'enterprise',
    avatarInitials: 'SA',
    emailVerified: true,
    twoFactorEnabled: true,
    createdAt: '2023-12-01T00:00:00Z',
    lastLoginAt: new Date().toISOString(),
  },
]

const MOCK_PASSWORDS: Record<string, string> = {
  'user@jadibot.com': 'User@1234!',
  'admin@jadibot.com': 'Admin@1234!',
  'superadmin@jadibot.com': 'SuperAdmin@1234!',
}

function generateMockToken(prefix: string): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  const arr = typeof crypto !== 'undefined' && crypto.getRandomValues
    ? crypto.getRandomValues(new Uint8Array(32))
    : Array.from({ length: 32 }, () => Math.floor(Math.random() * 256))
  return prefix + '_' + Array.from(arr).map((b) => chars[b % chars.length]).join('')
}

function generateDeviceId(): string {
  const stored = typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('jb_device_id') : null
  if (stored) return stored
  const id = generateMockToken('dev')
  if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('jb_device_id', id)
  return id
}

function buildTokens(rememberMe: boolean): AuthTokens {
  const now = Date.now()
  return {
    accessToken: generateMockToken('jb_at'),
    refreshToken: generateMockToken('jb_rt'),
    accessTokenExpiresAt: now + MOCK_ACCESS_TOKEN_EXPIRY_MS,
    refreshTokenExpiresAt: now + (rememberMe ? MOCK_REFRESH_TOKEN_REMEMBER_EXPIRY_MS : MOCK_REFRESH_TOKEN_EXPIRY_MS),
  }
}

export interface MockAuthResult {
  session: AuthSession
}

export async function mockLogin(credentials: LoginCredentials): Promise<MockAuthResult> {
  await new Promise((r) => setTimeout(r, 600))

  const user = MOCK_USERS.find((u) => u.email === credentials.email)
  const expectedPassword = MOCK_PASSWORDS[credentials.email]

  if (!user || expectedPassword !== credentials.password) {
    throw new Error('Invalid email or password.')
  }

  if (user.status === 'suspended') {
    throw new Error('Your account has been suspended. Please contact support.')
  }

  const tokens = buildTokens(credentials.rememberMe)
  const session: AuthSession = {
    user: { ...user, lastLoginAt: new Date().toISOString() },
    tokens,
    deviceId: generateDeviceId(),
    sessionId: generateMockToken('sess'),
    rememberMe: credentials.rememberMe,
    createdAt: Date.now(),
    lastActiveAt: Date.now(),
  }

  return { session }
}

export async function mockRegister(payload: RegisterCredentials): Promise<MockAuthResult> {
  await new Promise((r) => setTimeout(r, 800))

  const exists = MOCK_USERS.some((u) => u.email === payload.email)
  if (exists) throw new Error('An account with this email already exists.')

  const newUser: AuthUser = {
    id: `usr_${Date.now()}`,
    email: payload.email,
    name: `${payload.firstName} ${payload.lastName}`.trim(),
    role: 'user',
    status: 'active',
    plan: payload.plan,
    avatarInitials: `${payload.firstName[0] ?? '?'}${payload.lastName[0] ?? '?'}`.toUpperCase(),
    emailVerified: false,
    twoFactorEnabled: false,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  }

  const tokens = buildTokens(false)
  const session: AuthSession = {
    user: newUser,
    tokens,
    deviceId: generateDeviceId(),
    sessionId: generateMockToken('sess'),
    rememberMe: false,
    createdAt: Date.now(),
    lastActiveAt: Date.now(),
  }

  return { session }
}

export async function mockRefreshToken(refreshToken: string): Promise<AuthTokens> {
  await new Promise((r) => setTimeout(r, 200))
  if (!refreshToken.startsWith('jb_rt_')) {
    throw new Error('Invalid refresh token.')
  }
  return buildTokens(false)
}

export async function mockLogout(_sessionId: string): Promise<void> {
  await new Promise((r) => setTimeout(r, 200))
}

export async function mockLogoutAll(_userId: string): Promise<void> {
  await new Promise((r) => setTimeout(r, 300))
}

export async function mockForgotPassword(email: string): Promise<void> {
  await new Promise((r) => setTimeout(r, 700))
  const exists = MOCK_USERS.some((u) => u.email === email)
  if (!exists) return
}

export async function mockValidateSession(tokens: AuthTokens): Promise<AuthUser> {
  await new Promise((r) => setTimeout(r, 100))
  if (tokens.accessTokenExpiresAt < Date.now()) {
    throw new Error('Access token expired.')
  }
  return MOCK_USERS[0]
}
