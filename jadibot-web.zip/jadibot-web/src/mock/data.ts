import type {
  Bot, Activity, ChartDataPoint, Plugin,
  Command, Log, AppNotification, ApiKey, AdminUser
} from '@/types'

export const mockBots: Bot[] = [
  {
    id: 'bot-902a', name: 'JadiBot Primary', status: 'online', device: 'Linux Server (Ubuntu)',
    ping: 98, uptime: '14d 6h', messagesHandled: 52400, activeUsers: 1204, prefix: '.', mode: 'public',
    autoRead: true, autoTyping: false, autoRecording: false, autoReact: true,
    ownerName: 'Admin', ownerNumber: '6281234567890',
    bio: '🤖 Ready to assist you 24/7. Powered by JadiBot Enterprise.',
    language: 'en', timezone: 'Asia/Jakarta', footer: 'JadiBot Enterprise 2024',
  },
  {
    id: 'bot-404b', name: 'Support Bot Alpha', status: 'offline', device: 'AWS EC2 Instance',
    ping: null, uptime: '0', messagesHandled: 18320, activeUsers: 0, prefix: '!', mode: 'public',
    autoRead: false, autoTyping: false, autoRecording: false, autoReact: false,
    ownerName: 'Admin', ownerNumber: '6281234567890',
    bio: 'Customer support automation.',
    language: 'id', timezone: 'Asia/Jakarta', footer: 'Support Team',
  },
  {
    id: 'bot-771c', name: 'Sales Autopilot', status: 'online', device: 'GCP Compute Engine',
    ping: 42, uptime: '7d 12h', messagesHandled: 9870, activeUsers: 342, prefix: '#', mode: 'public',
    autoRead: true, autoTyping: true, autoRecording: false, autoReact: true,
    ownerName: 'Sales Team', ownerNumber: '6282233445566',
    bio: 'Your 24/7 sales assistant.',
    language: 'id', timezone: 'Asia/Jakarta', footer: 'JadiBot Sales 2024',
  },
  {
    id: 'bot-228d', name: 'Internal HR Bot', status: 'online', device: 'On-premise Server',
    ping: 15, uptime: '30d 0h', messagesHandled: 3210, activeUsers: 87, prefix: '/', mode: 'self',
    autoRead: true, autoTyping: false, autoRecording: false, autoReact: false,
    ownerName: 'HR Admin', ownerNumber: '6285566778899',
    bio: 'Internal HR automation for employees.',
    language: 'en', timezone: 'UTC', footer: 'HR Department',
  },
]

export const mockStats = {
  botOnline: 142,
  botOffline: 3,
  activeSessions: 8492,
  activeUsers: 45200,
  onlineTrend: '+12%',
  usersTrend: '+5.4%',
}

export const mockActivities: Activity[] = [
  { id: 1, type: 'connect', botId: 'Bot-ID-902', message: 'established new connection.', time: '2 mins ago', location: 'Asia-East (Singapore)' },
  { id: 2, type: 'message', botId: 'Support-Bot-1', message: 'handled 500+ messages.', time: '15 mins ago', location: 'Processing Queue' },
  { id: 3, type: 'disconnect', botId: 'Bot-ID-404', message: 'connection lost.', time: '1 hour ago', location: 'Auto-reconnect pending' },
  { id: 4, type: 'connect', botId: 'Sales-Bot-3', message: 'session resumed after brief downtime.', time: '2 hours ago', location: 'Southeast Asia (Jakarta)' },
  { id: 5, type: 'message', botId: 'HR-Bot-1', message: 'processed 100 attendance requests.', time: '3 hours ago', location: 'Internal Network' },
]

export const mockChartData: ChartDataPoint[] = [
  { date: 'Jun 22', messages: 12400, users: 890 },
  { date: 'Jun 23', messages: 15800, users: 1020 },
  { date: 'Jun 24', messages: 11200, users: 760 },
  { date: 'Jun 25', messages: 18900, users: 1340 },
  { date: 'Jun 26', messages: 21500, users: 1560 },
  { date: 'Jun 27', messages: 19300, users: 1420 },
  { date: 'Jun 28', messages: 24700, users: 1780 },
]

export const mockPlugins: Plugin[] = [
  { id: 'p1', name: 'AI Chat GPT', description: 'Integrate OpenAI GPT into your bot responses.', category: 'AI', status: 'active', version: '2.1.0', author: 'JadiBot Labs' },
  { id: 'p2', name: 'Auto Reply Pro', description: 'Advanced keyword-based auto reply system.', category: 'Automation', status: 'active', version: '1.5.3', author: 'Community' },
  { id: 'p3', name: 'Anti-Spam Shield', description: 'Detect and filter spam messages automatically.', category: 'Security', status: 'inactive', version: '1.0.1', author: 'JadiBot Labs' },
  { id: 'p4', name: 'Sticker Generator', description: 'Convert images and videos to WhatsApp stickers.', category: 'Media', status: 'active', version: '3.0.0', author: 'Community' },
  { id: 'p5', name: 'Group Manager', description: 'Full group administration automation.', category: 'Admin', status: 'active', version: '2.4.1', author: 'JadiBot Labs' },
  { id: 'p6', name: 'Payment Gateway', description: 'Accept payments directly via WhatsApp.', category: 'Commerce', status: 'inactive', version: '1.2.0', author: 'FinTech Partners' },
]

export const mockCommands: Command[] = [
  { id: 'c1', command: '.help', description: 'Show all available commands.', category: 'General', usage: 100, enabled: true },
  { id: 'c2', command: '.ping', description: 'Check bot latency and status.', category: 'General', usage: 78, enabled: true },
  { id: 'c3', command: '.sticker', description: 'Convert image to sticker.', category: 'Media', usage: 456, enabled: true },
  { id: 'c4', command: '.ai', description: 'Chat with AI assistant.', category: 'AI', usage: 892, enabled: true },
  { id: 'c5', command: '.ban', description: 'Ban a member from group.', category: 'Admin', usage: 23, enabled: false },
  { id: 'c6', command: '.mute', description: 'Mute a group member.', category: 'Admin', usage: 15, enabled: true },
]

export const mockLogs: Log[] = [
  { id: 'l1', level: 'info', message: 'Bot-ID-902 connected successfully', timestamp: '2024-06-28 10:02:14', source: 'Session Manager' },
  { id: 'l2', level: 'warn', message: 'High latency detected on Bot-ID-404: 2400ms', timestamp: '2024-06-28 09:47:30', source: 'Monitor' },
  { id: 'l3', level: 'error', message: 'Bot-ID-404 disconnected: ECONNRESET', timestamp: '2024-06-28 09:45:22', source: 'WebSocket' },
  { id: 'l4', level: 'info', message: '500 messages processed by Support-Bot-1', timestamp: '2024-06-28 09:30:00', source: 'Message Handler' },
  { id: 'l5', level: 'info', message: 'Plugin Anti-Spam Shield triggered: blocked 3 spam messages', timestamp: '2024-06-28 09:15:45', source: 'Plugin Engine' },
  { id: 'l6', level: 'debug', message: 'QR code generated for new session', timestamp: '2024-06-28 09:01:00', source: 'Session Manager' },
]

export const mockNotifications: AppNotification[] = [
  { id: 'n1', type: 'error', title: 'Bot Offline', message: 'Bot-ID-404 has gone offline unexpectedly.', time: '1 hour ago', read: false },
  { id: 'n2', type: 'success', title: 'New Connection', message: 'Bot-ID-902 established connection from Singapore.', time: '2 hours ago', read: false },
  { id: 'n3', type: 'warning', title: 'High Traffic', message: 'Support-Bot-1 handling 2x normal message volume.', time: '3 hours ago', read: true },
  { id: 'n4', type: 'info', title: 'Plugin Updated', message: 'AI Chat GPT plugin updated to v2.1.0.', time: '5 hours ago', read: true },
]

export const mockApiKeys: ApiKey[] = [
  { id: 'ak1', name: 'Production API Key', prefix: 'jb_live_', maskedKey: 'jb_live_••••••••••••••••Kx92', scope: ['read', 'write'], createdAt: '2024-01-15', lastUsed: '2024-06-28' },
  { id: 'ak2', name: 'Development Key', prefix: 'jb_dev_', maskedKey: 'jb_dev_••••••••••••••••3mPq', scope: ['read'], createdAt: '2024-03-22', lastUsed: '2024-06-27' },
]

export const mockUsers: AdminUser[] = [
  { id: 'u1', name: 'Arya Pratama', email: 'arya@company.com', plan: 'Enterprise', bots: 5, status: 'active', joinedAt: '2024-01-10' },
  { id: 'u2', name: 'Sari Dewi', email: 'sari@startup.id', plan: 'Pro', bots: 2, status: 'active', joinedAt: '2024-02-14' },
  { id: 'u3', name: 'Budi Santoso', email: 'budi@corp.com', plan: 'Starter', bots: 1, status: 'suspended', joinedAt: '2024-03-01' },
  { id: 'u4', name: 'Lina Marlina', email: 'lina@agency.co', plan: 'Pro', bots: 3, status: 'active', joinedAt: '2024-03-20' },
  { id: 'u5', name: 'Doni Rahman', email: 'doni@freelance.dev', plan: 'Starter', bots: 1, status: 'active', joinedAt: '2024-04-05' },
]
