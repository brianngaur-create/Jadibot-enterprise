'use client'

import { X, QrCode } from 'lucide-react'

interface QRCodeModalProps {
  isOpen: boolean
  onClose: () => void
  botName: string
}

export function QRCodeModal({ isOpen, onClose, botName }: QRCodeModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-[#111827] border border-[#1F2937] rounded-xl w-full max-w-sm overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-[#1F2937]">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <QrCode className="w-4 h-4 text-primary" />
            Link Device: {botName}
          </h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-8 flex flex-col items-center">
          <div className="bg-white p-4 rounded-lg mb-6">
            <div className="w-48 h-48 bg-black grid grid-cols-7 grid-rows-7 gap-0.5 p-2">
              {Array.from({ length: 49 }).map((_, i) => (
                <div
                  key={i}
                  className={`${
                    [0,1,2,3,4,5,6,7,13,14,20,21,22,23,24,25,26,27,34,40,41,42,43,44,45,46,47,48].includes(i)
                      ? 'bg-black'
                      : i % 3 === 0 ? 'bg-black' : 'bg-white'
                  }`}
                />
              ))}
            </div>
          </div>

          <h4 className="text-center font-medium text-foreground mb-2">Scan QR Code</h4>
          <ol className="text-sm text-muted-foreground list-decimal list-inside space-y-1 max-w-[250px]">
            <li>Open WhatsApp on your phone</li>
            <li>Tap Menu or Settings and select Linked Devices</li>
            <li>Tap on Link a Device</li>
            <li>Point your phone to this screen</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
